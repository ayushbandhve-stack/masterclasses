<?php
/**
 * Single article template.
 *
 * @package JanDristi_News
 */
get_header();
?>
<main class="jdn-container jdn-main" id="jdn-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="jdn-breadcrumbs"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'होम', 'jandristi-news' ); ?></a><span aria-hidden="true"> / </span><?php the_category( ' / ' ); ?></div>
		<div class="jdn-article-layout">
			<article <?php post_class( 'jdn-article' ); ?>>
				<?php jdn_category_badge(); ?>
				<h1><?php the_title(); ?></h1>
				<div class="jdn-article-byline"><span><?php esc_html_e( 'लेखक', 'jandristi-news' ); ?>: <?php the_author_posts_link(); ?></span><span class="jdn-dot" aria-hidden="true"></span><span><?php echo esc_html( get_the_date() ); ?></span><span class="jdn-dot" aria-hidden="true"></span><span><?php echo esc_html( jdn_reading_time() ); ?></span></div>
				<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'jdn-feature', array( 'class' => 'jdn-article-featured', 'loading' => 'eager' ) ); endif; ?>
				<div class="jdn-article-content"><?php the_content(); ?></div>
				<?php wp_link_pages( array( 'before' => '<div class="jdn-page-links"><span>' . esc_html__( 'पेज:', 'jandristi-news' ) . '</span>', 'after' => '</div>' ) ); ?>
				<?php if ( has_tag() ) : ?><div class="jdn-post-tags"><strong><?php esc_html_e( 'टैग:', 'jandristi-news' ); ?></strong> <?php the_tags( '', ', ' ); ?></div><?php endif; ?>
				<nav class="jdn-post-navigation" aria-label="<?php esc_attr_e( 'लेख नेविगेशन', 'jandristi-news' ); ?>"><div><?php previous_post_link( '%link', '← %title' ); ?></div><div><?php next_post_link( '%link', '%title →' ); ?></div></nav>
				<?php if ( comments_open() || get_comments_number() ) : ?><section class="jdn-comments"><?php comments_template(); ?></section><?php endif; ?>
			</article>
			<aside class="jdn-article-sidebar">
				<?php if ( is_active_sidebar( 'article-sidebar' ) ) : dynamic_sidebar( 'article-sidebar' ); else : ?>
					<h2><?php esc_html_e( 'और खबरें', 'jandristi-news' ); ?></h2>
					<ul class="jdn-related-list"><?php
					$related = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 5, 'post__not_in' => array( get_the_ID() ), 'ignore_sticky_posts' => true ) );
					while ( $related->have_posts() ) : $related->the_post();
						echo '<li><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></li>';
					endwhile;
					wp_reset_postdata();
					?></ul>
				<?php endif; ?>
			</aside>
		</div>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
