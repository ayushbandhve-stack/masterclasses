<?php
/**
 * Homepage template.
 *
 * @package JanDristi_News
 */
get_header();
$hero_query = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 4, 'ignore_sticky_posts' => false ) );
$hero_posts = $hero_query->posts;
$hero_ids = wp_list_pluck( $hero_posts, 'ID' );
?>
<main class="jdn-main" id="jdn-main">
	<section class="jdn-container jdn-hero">
		<div class="jdn-section-top"><span class="jdn-eyebrow"><?php esc_html_e( 'आज की बड़ी खबरें', 'jandristi-news' ); ?></span><p><?php echo esc_html( get_theme_mod( 'jdn_home_intro', 'ताज़ा खबरें, उपयोगी गाइड और आपकी ज़िंदगी से जुड़ी जानकारी।' ) ); ?></p></div>
		<?php if ( ! empty( $hero_posts ) ) : $hero = $hero_posts[0]; ?>
			<div class="jdn-hero-layout">
				<article class="jdn-hero-feature">
					<a class="jdn-hero-image" href="<?php echo esc_url( get_permalink( $hero->ID ) ); ?>" aria-label="<?php echo esc_attr( get_the_title( $hero->ID ) ); ?>">
						<?php if ( has_post_thumbnail( $hero->ID ) ) { echo get_the_post_thumbnail( $hero->ID, 'jdn-feature', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); } else { echo '<span class="jdn-image-placeholder jdn-placeholder-large" aria-hidden="true"><span>ज</span></span>'; } ?>
					</a>
					<div class="jdn-hero-overlay">
						<?php jdn_category_badge( $hero->ID ); ?>
						<h1><a href="<?php echo esc_url( get_permalink( $hero->ID ) ); ?>"><?php echo esc_html( get_the_title( $hero->ID ) ); ?></a></h1>
						<p><?php echo esc_html( wp_trim_words( get_the_excerpt( $hero->ID ), 28 ) ); ?></p>
						<div class="jdn-meta"><span><?php echo esc_html( get_the_author_meta( 'display_name', $hero->post_author ) ); ?></span><span class="jdn-dot" aria-hidden="true"></span><span><?php echo esc_html( get_the_date( '', $hero->ID ) ); ?></span><span class="jdn-dot" aria-hidden="true"></span><span><?php echo esc_html( jdn_reading_time( $hero->ID ) ); ?></span></div>
					</div>
				</article>
				<div class="jdn-hero-side">
					<?php foreach ( array_slice( $hero_posts, 1, 3 ) as $side ) : ?>
						<article class="jdn-side-story">
							<a class="jdn-side-image" href="<?php echo esc_url( get_permalink( $side->ID ) ); ?>">
								<?php if ( has_post_thumbnail( $side->ID ) ) { echo get_the_post_thumbnail( $side->ID, 'medium', array( 'loading' => 'lazy' ) ); } else { echo '<span class="jdn-image-placeholder" aria-hidden="true"><span>ज</span></span>'; } ?>
							</a>
							<div class="jdn-side-copy"><?php jdn_category_badge( $side->ID ); ?><h2><a href="<?php echo esc_url( get_permalink( $side->ID ) ); ?>"><?php echo esc_html( get_the_title( $side->ID ) ); ?></a></h2><div class="jdn-meta"><span><?php echo esc_html( get_the_date( '', $side->ID ) ); ?></span></div></div>
						</article>
					<?php endforeach; ?>
				</div>
			</div>
		<?php else : ?>
			<div class="jdn-empty"><h2><?php esc_html_e( 'अभी कोई पोस्ट प्रकाशित नहीं है।', 'jandristi-news' ); ?></h2><p><?php esc_html_e( 'WordPress में पोस्ट प्रकाशित करें। आपकी खबरें यहाँ अपने आप दिखाई देंगी।', 'jandristi-news' ); ?></p><a class="jdn-button" href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>"><?php esc_html_e( 'पहली पोस्ट लिखें', 'jandristi-news' ); ?></a></div>
		<?php endif; ?>
		<div class="jdn-trust-row"><div><span aria-hidden="true">✦</span><p><strong><?php esc_html_e( 'काम की जानकारी', 'jandristi-news' ); ?></strong><small><?php esc_html_e( 'सीधी और आसान भाषा', 'jandristi-news' ); ?></small></p></div><div><span aria-hidden="true">◷</span><p><strong><?php esc_html_e( 'नए अपडेट', 'jandristi-news' ); ?></strong><small><?php esc_html_e( 'ज़रूरी बात, बिना शोर', 'jandristi-news' ); ?></small></p></div><div><span aria-hidden="true">✓</span><p><strong><?php esc_html_e( 'पाठक पहले', 'jandristi-news' ); ?></strong><small><?php esc_html_e( 'उपयोगी संदर्भ और गाइड', 'jandristi-news' ); ?></small></p></div></div>
	</section>

	<section class="jdn-container jdn-section">
		<div class="jdn-section-heading"><div><span class="jdn-eyebrow"><?php esc_html_e( 'सबसे नई', 'jandristi-news' ); ?></span><h2><?php esc_html_e( 'ताज़ा खबरें', 'jandristi-news' ); ?></h2><p><?php esc_html_e( 'नई पोस्ट और ज़रूरी अपडेट एक जगह।', 'jandristi-news' ); ?></p></div><a class="jdn-view-all" href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ?: home_url( '/' ) ); ?>"><?php esc_html_e( 'सभी खबरें', 'jandristi-news' ); ?> <span aria-hidden="true">→</span></a></div>
		<div class="jdn-filter-tabs" role="group" aria-label="<?php esc_attr_e( 'श्रेणी के अनुसार फ़िल्टर करें', 'jandristi-news' ); ?>">
			<button type="button" class="jdn-filter" data-filter="all" aria-pressed="true"><?php esc_html_e( 'सभी', 'jandristi-news' ); ?></button>
			<?php foreach ( get_categories( array( 'hide_empty' => true, 'number' => 8 ) ) as $category ) : ?>
				<button type="button" class="jdn-filter" data-filter="<?php echo esc_attr( $category->slug ); ?>" aria-pressed="false"><?php echo esc_html( $category->name ); ?></button>
			<?php endforeach; ?>
		</div>
		<div class="jdn-card-grid" id="jdn-latest-grid">
			<?php
			$latest = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 9, 'post__not_in' => $hero_ids, 'ignore_sticky_posts' => true ) );
			if ( $latest->have_posts() ) :
				while ( $latest->have_posts() ) : $latest->the_post();
					jdn_post_card();
				endwhile;
				wp_reset_postdata();
			elseif ( empty( $hero_posts ) ) :
				echo '<div class="jdn-empty"><strong>' . esc_html__( 'यहाँ अभी खबरें नहीं हैं।', 'jandristi-news' ) . '</strong><p>' . esc_html__( 'पहली पोस्ट प्रकाशित होने पर यह सेक्शन अपने आप भर जाएगा।', 'jandristi-news' ) . '</p></div>';
			else :
				foreach ( array_slice( $hero_posts, 0, 3 ) as $fallback_post ) { jdn_post_card( $fallback_post->ID ); }
			endif;
			?>
		</div>
		<div class="jdn-filter-empty" id="jdn-filter-empty" hidden role="status"><?php esc_html_e( 'इस श्रेणी में पोस्ट नहीं मिली। दूसरी श्रेणी चुनें।', 'jandristi-news' ); ?></div>
	</section>

	<section class="jdn-container jdn-section">
		<div class="jdn-feature-banner"><div><span class="jdn-badge"><?php esc_html_e( 'विशेष कवरेज', 'jandristi-news' ); ?></span><h2><?php esc_html_e( 'हर विषय की खबर, आपके समझने के अंदाज़ में', 'jandristi-news' ); ?></h2><p><?php esc_html_e( 'ऑटोमोबाइल, टेक्नोलॉजी, फाइनेंस, एजुकेशन और मनोरंजन की नई कहानियाँ पढ़ें।', 'jandristi-news' ); ?></p></div><div class="jdn-banner-symbol" aria-hidden="true">ज</div></div>
	</section>

	<section class="jdn-container jdn-section jdn-topic-sections">
		<?php
		$section_candidates = array(
			array( 'title' => 'टेक्नोलॉजी', 'slugs' => array( 'technology', 'tech', 'टेक्नोलॉजी' ) ),
			array( 'title' => 'ऑटोमोबाइल', 'slugs' => array( 'automobile', 'auto', 'ऑटोमोबाइल' ) ),
			array( 'title' => 'बिज़नेस', 'slugs' => array( 'business', 'बिज़नेस' ) ),
			array( 'title' => 'एजुकेशन', 'slugs' => array( 'education', 'एजुकेशन' ) ),
		);
		foreach ( $section_candidates as $section ) :
			$term = null;
			foreach ( $section['slugs'] as $slug ) {
				$term = get_category_by_slug( sanitize_title( $slug ) );
				if ( ! $term ) { $term = get_term_by( 'name', $slug, 'category' ); }
				if ( $term && ! is_wp_error( $term ) ) { break; }
			}
			if ( ! $term || is_wp_error( $term ) || 0 === (int) $term->count ) { continue; }
			$section_posts = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'cat' => $term->term_id, 'posts_per_page' => 4, 'ignore_sticky_posts' => true ) );
			if ( ! $section_posts->have_posts() ) { wp_reset_postdata(); continue; }
			?>
			<div class="jdn-topic-section">
				<div class="jdn-section-heading"><div><span class="jdn-eyebrow"><?php esc_html_e( 'श्रेणी', 'jandristi-news' ); ?></span><h2><?php echo esc_html( $term->name ); ?></h2></div><a class="jdn-view-all" href="<?php echo esc_url( get_category_link( $term->term_id ) ); ?>"><?php esc_html_e( 'और पढ़ें', 'jandristi-news' ); ?> →</a></div>
				<div class="jdn-card-grid jdn-card-grid-four"><?php while ( $section_posts->have_posts() ) : $section_posts->the_post(); jdn_post_card(); endwhile; ?></div>
			</div>
			<?php wp_reset_postdata(); ?>
		<?php endforeach; ?>
	</section>
</main>
<?php get_footer(); ?>
