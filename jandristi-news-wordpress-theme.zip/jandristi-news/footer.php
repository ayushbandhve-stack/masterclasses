<?php
/**
 * Footer template.
 *
 * @package JanDristi_News
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<footer class="jdn-footer">
	<div class="jdn-container jdn-footer-grid">
		<div class="jdn-footer-about">
			<a class="jdn-brand jdn-footer-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<span class="jdn-brand-icon" aria-hidden="true">ज</span>
				<span class="jdn-brand-copy"><strong><?php echo esc_html( get_bloginfo( 'name' ) ); ?></strong><small><?php echo esc_html( get_bloginfo( 'description' ) ); ?></small></span>
			</a>
			<p><?php esc_html_e( 'शिक्षा, मनोरंजन, ऑटोमोबाइल, बिज़नेस और टेक्नोलॉजी से जुड़ी उपयोगी जानकारी—सरल भाषा में।', 'jandristi-news' ); ?></p>
		</div>
		<div class="jdn-footer-col"><h2><?php esc_html_e( 'श्रेणियाँ', 'jandristi-news' ); ?></h2>
			<?php wp_list_categories( array( 'title_li' => '', 'show_count' => false, 'number' => 7, 'hide_empty' => true ) ); ?>
		</div>
		<div class="jdn-footer-col"><h2><?php esc_html_e( 'जानकारी', 'jandristi-news' ); ?></h2>
			<?php
			$pages = get_pages( array( 'number' => 5, 'sort_column' => 'menu_order,post_title' ) );
			if ( $pages ) {
				echo '<ul>';
				foreach ( $pages as $page ) {
					echo '<li><a href="' . esc_url( get_permalink( $page->ID ) ) . '">' . esc_html( get_the_title( $page->ID ) ) . '</a></li>';
				}
				echo '</ul>';
			} else {
				echo '<ul><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'हमारे बारे में पेज जोड़ें', 'jandristi-news' ) . '</a></li><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'संपर्क पेज जोड़ें', 'jandristi-news' ) . '</a></li></ul>';
			}
			?>
		</div>
		<div class="jdn-footer-col"><h2><?php esc_html_e( 'संपर्क और नीतियाँ', 'jandristi-news' ); ?></h2>
			<?php if ( has_nav_menu( 'footer' ) ) { wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => 'jdn-footer-menu', 'fallback_cb' => false ) ); } else { ?>
				<ul><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'संपर्क करें', 'jandristi-news' ); ?></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'गोपनीयता नीति', 'jandristi-news' ); ?></a></li></ul>
			<?php } ?>
		</div>
	</div>
	<div class="jdn-container jdn-footer-bottom"><span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'सर्वाधिकार सुरक्षित।', 'jandristi-news' ); ?></span><span><?php esc_html_e( 'स्पष्ट जानकारी, बेहतर फैसले।', 'jandristi-news' ); ?></span></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
