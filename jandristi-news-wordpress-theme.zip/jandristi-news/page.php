<?php
/**
 * Static page template.
 *
 * @package JanDristi_News
 */
get_header();
?>
<main class="jdn-container jdn-main" id="jdn-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'jdn-page-article' ); ?>>
			<h1><?php the_title(); ?></h1>
			<?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'large', array( 'class' => 'jdn-article-featured' ) ); endif; ?>
			<div class="jdn-article-content"><?php the_content(); ?></div>
			<?php if ( comments_open() || get_comments_number() ) : comments_template(); endif; ?>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
