<?php
/**
 * JanDristi News theme functions.
 *
 * @package JanDristi_News
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function jdn_setup() {
	load_theme_textdomain( 'jandristi-news', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 280, 'flex-height' => true, 'flex-width' => true ) );
	add_image_size( 'jdn-card', 640, 360, true );
	add_image_size( 'jdn-feature', 1200, 650, true );
	register_nav_menus( array(
		'primary' => __( 'Primary Navigation', 'jandristi-news' ),
		'footer'  => __( 'Footer Navigation', 'jandristi-news' ),
	) );
	register_sidebar( array(
		'name' => __( 'Article Sidebar', 'jandristi-news' ),
		'id' => 'article-sidebar',
		'description' => __( 'Widgets displayed beside articles on wide screens.', 'jandristi-news' ),
		'before_widget' => '<section id="%1$s" class="jdn-widget %2$s">',
		'after_widget' => '</section>',
		'before_title' => '<h2 class="jdn-widget-title">',
		'after_title' => '</h2>',
	) );
}
add_action( 'after_setup_theme', 'jdn_setup' );

function jdn_assets() {
	wp_enqueue_style( 'jdn-style', get_stylesheet_uri(), array(), '1.0.0' );
	wp_enqueue_style( 'jdn-layout', get_template_directory_uri() . '/assets/css/theme.css', array( 'jdn-style' ), '1.0.0' );
	wp_enqueue_script( 'jdn-script', get_template_directory_uri() . '/assets/js/theme.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'jdn_assets' );

function jdn_excerpt_length( $length ) { return 25; }
add_filter( 'excerpt_length', 'jdn_excerpt_length', 99 );
function jdn_excerpt_more( $more ) { return '…'; }
add_filter( 'excerpt_more', 'jdn_excerpt_more' );

function jdn_body_classes( $classes ) {
	if ( is_singular() ) { $classes[] = 'jdn-singular'; }
	return $classes;
}
add_filter( 'body_class', 'jdn_body_classes' );

function jdn_reading_time( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$content = get_post_field( 'post_content', $post_id );
	$words = preg_match_all( '/[\p{L}\p{N}]+/u', wp_strip_all_tags( strip_shortcodes( $content ) ), $matches );
	$minutes = max( 1, (int) ceil( (int) $words / 200 ) );
	return sprintf( _n( '%d मिनट पढ़ें', '%d मिनट पढ़ें', $minutes, 'jandristi-news' ), $minutes );
}

function jdn_category_badge( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$categories = get_the_category( $post_id );
	if ( ! empty( $categories ) ) {
		$cat = $categories[0];
		echo '<a class="jdn-badge" href="' . esc_url( get_category_link( $cat->term_id ) ) . '">' . esc_html( $cat->name ) . '</a>';
	} else {
		echo '<span class="jdn-badge">' . esc_html__( 'समाचार', 'jandristi-news' ) . '</span>';
	}
}

function jdn_post_meta( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	echo '<div class="jdn-meta"><span>' . esc_html( get_the_date( '', $post_id ) ) . '</span><span class="jdn-dot" aria-hidden="true"></span><span>' . esc_html( jdn_reading_time( $post_id ) ) . '</span></div>';
}

function jdn_post_card( $post_id = 0, $layout = 'card' ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$classes = 'jdn-card';
	if ( 'compact' === $layout ) { $classes .= ' jdn-card-compact'; }
	?>
	<article <?php post_class( $classes, $post_id ); ?>>
		<a class="jdn-card-link" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>">
			<div class="jdn-card-media">
				<?php if ( has_post_thumbnail( $post_id ) ) : ?>
					<?php echo get_the_post_thumbnail( $post_id, 'jdn-card', array( 'loading' => 'lazy' ) ); ?>
				<?php else : ?>
					<div class="jdn-image-placeholder" aria-hidden="true"><span>ज</span></div>
				<?php endif; ?>
			</div>
			<div class="jdn-card-content">
				<?php jdn_category_badge( $post_id ); ?>
				<h3><?php echo esc_html( get_the_title( $post_id ) ); ?></h3>
				<p><?php echo esc_html( get_the_excerpt( $post_id ) ); ?></p>
				<?php jdn_post_meta( $post_id ); ?>
			</div>
		</a>
	</article>
	<?php
}

function jdn_category_url_by_names( $names ) {
	foreach ( (array) $names as $name ) {
		$cat = get_category_by_slug( sanitize_title( $name ) );
		if ( ! $cat ) { $cat = get_term_by( 'name', $name, 'category' ); }
		if ( $cat && ! is_wp_error( $cat ) ) { return get_category_link( $cat->term_id ); }
	}
	return get_category_link( get_option( 'default_category' ) );
}

function jdn_posts_per_page( $query ) {
	if ( ! is_admin() && $query->is_main_query() && ( $query->is_archive() || $query->is_search() || $query->is_home() ) ) {
		$query->set( 'posts_per_page', 12 );
	}
}
add_action( 'pre_get_posts', 'jdn_posts_per_page' );

function jdn_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'jdn_home_settings', array(
		'title' => __( 'JanDristi Homepage', 'jandristi-news' ),
		'priority' => 35,
	) );
	$wp_customize->add_setting( 'jdn_breaking_text', array(
		'default' => 'आज की ज़रूरी खबरें, काम की जानकारी और नए ट्रेंड — एक ही जगह',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'jdn_breaking_text', array(
		'label' => __( 'Top ticker text', 'jandristi-news' ),
		'section' => 'jdn_home_settings',
		'type' => 'text',
	) );
	$wp_customize->add_setting( 'jdn_home_intro', array(
		'default' => 'ताज़ा खबरें, उपयोगी गाइड और आपकी ज़िंदगी से जुड़ी जानकारी।',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'jdn_home_intro', array(
		'label' => __( 'Homepage intro text', 'jandristi-news' ),
		'section' => 'jdn_home_settings',
		'type' => 'text',
	) );
}
add_action( 'customize_register', 'jdn_customize_register' );

function jdn_fallback_menu() {
	$items = array(
		'होम' => home_url( '/' ),
		'ऑटोमोबाइल' => jdn_category_url_by_names( array( 'ऑटोमोबाइल', 'automobile', 'auto' ) ),
		'बिज़नेस' => jdn_category_url_by_names( array( 'बिज़नेस', 'business' ) ),
		'टेक्नोलॉजी' => jdn_category_url_by_names( array( 'टेक्नोलॉजी', 'technology', 'tech' ) ),
		'फाइनेंस' => jdn_category_url_by_names( array( 'फाइनेंस', 'finance' ) ),
		'मनोरंजन' => jdn_category_url_by_names( array( 'मनोरंजन', 'entertainment' ) ),
		'एजुकेशन' => jdn_category_url_by_names( array( 'एजुकेशन', 'education' ) ),
		'खेल' => jdn_category_url_by_names( array( 'खेल', 'sports' ) ),
	);
	foreach ( $items as $label => $url ) {
		if ( ! is_wp_error( $url ) ) {
			echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
		}
	}
}

function jdn_primary_menu( $menu_id = 'jdn-primary-menu' ) {
	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_id' => sanitize_html_class( $menu_id ), 'menu_class' => 'jdn-menu-list', 'fallback_cb' => false ) );
	} else {
		echo '<ul class="jdn-menu-list">';
		jdn_fallback_menu();
		echo '</ul>';
	}
}
