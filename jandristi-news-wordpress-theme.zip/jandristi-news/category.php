<?php
/**
 * Category archive template.
 *
 * @package JanDristi_News
 */
get_header();
$category = get_queried_object();
?>
<main class="jdn-container jdn-main jdn-archive" id="jdn-main">
	<header class="jdn-archive-heading"><span class="jdn-eyebrow"><?php esc_html_e( 'श्रेणी', 'jandristi-news' ); ?></span><h1><?php single_cat_title(); ?></h1><?php the_archive_description( '<div class="jdn-archive-description">', '</div>' ); ?></header>
	<div class="jdn-card-grid"><?php if ( have_posts() ) : while ( have_posts() ) : the_post(); jdn_post_card(); endwhile; else : ?><div class="jdn-empty"><strong><?php esc_html_e( 'इस श्रेणी में अभी कोई पोस्ट नहीं है।', 'jandristi-news' ); ?></strong></div><?php endif; ?></div>
	<?php if ( have_posts() ) : ?><nav class="jdn-pagination" aria-label="<?php esc_attr_e( 'पेज नेविगेशन', 'jandristi-news' ); ?>"><?php echo wp_kses_post( paginate_links() ); ?></nav><?php endif; ?>
</main>
<?php get_footer(); ?>
