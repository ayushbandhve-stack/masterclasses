<?php
/**
 * Posts index template.
 *
 * @package JanDristi_News
 */
get_template_part( 'index' );
