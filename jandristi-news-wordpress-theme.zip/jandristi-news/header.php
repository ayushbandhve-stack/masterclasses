<?php
/**
 * Header template.
 *
 * @package JanDristi_News
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$site_name = get_bloginfo( 'name' );
$tagline = get_bloginfo( 'description' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#jdn-main"><?php esc_html_e( 'मुख्य सामग्री पर जाएँ', 'jandristi-news' ); ?></a>
<div class="jdn-topline">
	<div class="jdn-container jdn-topline-inner">
		<span class="jdn-country" aria-hidden="true">भारत</span>
		<span class="jdn-ticker-text"><?php echo esc_html( get_theme_mod( 'jdn_breaking_text', 'आज की ज़रूरी खबरें, काम की जानकारी और नए ट्रेंड — एक ही जगह' ) ); ?></span>
		<div class="jdn-language-links"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" lang="hi">हिन्दी</a><span aria-hidden="true">/</span><a href="<?php echo esc_url( home_url( '/' ) ); ?>" lang="en">English</a></div>
	</div>
</div>
<header class="jdn-header">
	<div class="jdn-container jdn-header-main">
		<?php if ( has_custom_logo() ) : ?>
			<div class="jdn-brand jdn-brand-custom"><?php the_custom_logo(); ?></div>
		<?php else : ?>
			<a class="jdn-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( $site_name . ' होम' ); ?>">
				<span class="jdn-brand-icon" aria-hidden="true">ज</span>
				<span class="jdn-brand-copy"><strong><?php echo esc_html( $site_name ? $site_name : 'जनदृष्टि' ); ?></strong><small><?php echo esc_html( $tagline ? $tagline : 'खबरें, जो काम आएँ' ); ?></small></span>
			</a>
		<?php endif; ?>
		<nav class="jdn-primary-nav" aria-label="<?php esc_attr_e( 'मुख्य नेविगेशन', 'jandristi-news' ); ?>">
			<?php jdn_primary_menu( 'jdn-desktop-menu' ); ?>
		</nav>
		<div class="jdn-header-tools">
			<button class="jdn-tool-button" id="jdn-search-toggle" type="button" aria-label="<?php esc_attr_e( 'खोज खोलें', 'jandristi-news' ); ?>" aria-expanded="false" aria-controls="jdn-search-panel">
				<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8" fill="none" stroke="currentColor" stroke-width="2"/><path d="m16 16 5 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
			</button>
			<button class="jdn-tool-button jdn-mobile-toggle" id="jdn-mobile-toggle" type="button" aria-label="<?php esc_attr_e( 'मेन्यू खोलें', 'jandristi-news' ); ?>" aria-expanded="false" aria-controls="jdn-mobile-nav">
				<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
			</button>
		</div>
		<div class="jdn-search-panel" id="jdn-search-panel"><?php get_search_form(); ?></div>
	</div>
	<nav class="jdn-container jdn-mobile-nav" id="jdn-mobile-nav" aria-label="<?php esc_attr_e( 'मोबाइल नेविगेशन', 'jandristi-news' ); ?>">
		<?php jdn_primary_menu( 'jdn-mobile-menu' ); ?>
	</nav>
</header>
