<?php
/**
 * Comments template.
 *
 * @package JanDristi_News
 */
if ( post_password_required() ) { return; }
?>
<div id="comments" class="jdn-comment-area">
	<?php if ( have_comments() ) : ?>
		<h2><?php printf( esc_html( _nx( 'एक टिप्पणी', '%1$s टिप्पणियाँ', get_comments_number(), 'comments title', 'jandristi-news' ) ), number_format_i18n( get_comments_number() ) ); ?></h2>
		<ol class="jdn-comment-list"><?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true, 'avatar_size' => 40 ) ); ?></ol>
		<?php the_comments_navigation(); ?>
	<?php endif; ?>
	<?php if ( ! comments_open() && get_comments_number() ) : ?><p><?php esc_html_e( 'टिप्पणियाँ बंद हैं।', 'jandristi-news' ); ?></p><?php endif; ?>
	<?php comment_form(); ?>
</div>
