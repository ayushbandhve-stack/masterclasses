JANDRISTI NEWS — INSTALLABLE WORDPRESS THEME
============================================

This theme was built from the general editorial layout pattern in the user-provided website archive. It is an original implementation: it does not include the downloaded site's logo, hard-coded article text, original stylesheet, or copied image assets. It uses your own WordPress posts, featured images, categories and site settings.

INSTALL
------
1. Back up the current website database and files. If possible, create a staging copy.
2. In WordPress, go to Appearance > Themes > Add New Theme > Upload Theme.
3. Upload jandristi-news-wordpress-theme.zip and click Install Now.
4. Keep the existing Newsup Child theme installed. Installing this theme does not overwrite it.
5. Preview this theme on staging. Check homepage, category pages, articles, search, navigation, comments, mobile, AMP (if used), and SEO output.
6. When ready, activate “JanDristi News” from Appearance > Themes. The existing theme remains available for rollback.
7. Set the WordPress Site Title and Tagline under Settings > General. The header uses these automatically.
8. Configure the menu under Appearance > Menus, assign it to “Primary Navigation”, and optionally assign a footer menu.
9. Set featured images on posts and assign categories. Dynamic homepage and archive cards will use them.
10. Optional: go to Appearance > Customize > JanDristi Homepage to change the ticker text and homepage intro (availability depends on your WordPress configuration).
11. Purge LiteSpeed Cache or other caches after switching themes.

FUNCTIONALITY
-------------
- Dynamic homepage hero and three side stories from latest published WordPress posts.
- Dynamic latest-post cards, category filtering, and category sections (sections appear when matching categories exist).
- Dynamic single article pages, featured images, author/date/reading time, tags, comments, previous/next article links.
- Category archives, search results, date/author/tag archives, pagination, static pages and a 404 template.
- WordPress menu locations, custom logo support, a widget area for article sidebar, and footer category/page links.
- Responsive desktop/tablet/mobile layout, keyboard focus states, skip link, Escape-to-close interactions, reduced-motion support.
- Uses the existing WordPress post database. It does not import the archived site's content or create fake posts.

IMPORTANT
---------
- A static website download cannot recover the original WordPress database, original admin access, PHP templates, plugins, or post metadata. This theme recreates the editorial structure but does not migrate the original website's posts.
- You must have your own rights/permission for all posts, images, logos, and brand assets you upload. This ZIP intentionally excludes the source site's logo, scraped article copy, and downloaded images.
- Newsletter subscription, social integrations, analytics, ad slots and multilingual switching are not connected. Add reputable plugins/services if you need those features.
- SEO plugin metadata (Rank Math, Yoast etc.) should continue to be managed by the plugin. This theme does not hard-code the source site's canonical URLs, schema, analytics, ad scripts or site identity.
- If you use AMP, test with your installed AMP plugin before deploying. This is not a guarantee of AMP compatibility.
- If homepage sections are empty, publish posts, set featured images, and create matching categories. The latest-news section still works even if category sections are absent.
- Check with your host for the supported PHP and WordPress versions. Test plugin conflicts and mobile behavior on staging before replacing a live theme.

ROLLBACK
--------
If the design or plugins break, go to Appearance > Themes and activate your previous Newsup Child theme. Do not delete the old theme until the new one is verified.
