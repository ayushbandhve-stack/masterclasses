<?php
/**
 * Archive, blog and search fallback.
 *
 * @package JanDristi_News
 */
get_header();
?>
<main class="jdn-container jdn-main jdn-archive" id="jdn-main">
	<header class="jdn-archive-heading"><span class="jdn-eyebrow"><?php esc_html_e( 'जनदृष्टि', 'jandristi-news' ); ?></span>
		<h1><?php
		if ( is_search() ) { printf( esc_html__( 'खोज परिणाम: %s', 'jandristi-news' ), esc_html( get_search_query() ) ); }
		elseif ( is_category() ) { single_cat_title(); }
		elseif ( is_tag() ) { single_tag_title(); }
		elseif ( is_author() ) { the_post(); echo esc_html( get_the_author() ); rewind_posts(); }
		elseif ( is_date() ) { echo esc_html( get_the_archive_title() ); }
		else { esc_html_e( 'ताज़ा खबरें', 'jandristi-news' ); }
		?></h1>
		<?php the_archive_description( '<div class="jdn-archive-description">', '</div>' ); ?>
	</header>
	<div class="jdn-card-grid">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); jdn_post_card(); endwhile; else : ?>
			<div class="jdn-empty"><strong><?php esc_html_e( 'कोई पोस्ट नहीं मिली।', 'jandristi-news' ); ?></strong><p><?php esc_html_e( 'खोज के शब्द बदलें या दूसरी श्रेणी चुनें।', 'jandristi-news' ); ?></p><?php get_search_form(); ?></div>
		<?php endif; ?>
	</div>
	<?php if ( have_posts() ) : ?><nav class="jdn-pagination" aria-label="<?php esc_attr_e( 'पेज नेविगेशन', 'jandristi-news' ); ?>"><?php echo wp_kses_post( paginate_links( array( 'prev_text' => '← ' . __( 'पिछला', 'jandristi-news' ), 'next_text' => __( 'अगला', 'jandristi-news' ) . ' →' ) ) ); ?></nav><?php endif; ?>
</main>
<?php get_footer(); ?>
