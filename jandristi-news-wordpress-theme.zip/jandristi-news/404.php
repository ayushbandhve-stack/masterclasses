<?php
/**
 * 404 page.
 *
 * @package JanDristi_News
 */
get_header();
?>
<main class="jdn-container jdn-main jdn-404" id="jdn-main">
	<span class="jdn-eyebrow"><?php esc_html_e( '404 त्रुटि', 'jandristi-news' ); ?></span>
	<h1><?php esc_html_e( 'यह पेज नहीं मिला', 'jandristi-news' ); ?></h1>
	<p><?php esc_html_e( 'यह लिंक बदल गया हो सकता है। खबर खोजें या होमपेज पर लौटें।', 'jandristi-news' ); ?></p>
	<?php get_search_form(); ?>
	<a class="jdn-button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'होमपेज पर जाएँ', 'jandristi-news' ); ?></a>
</main>
<?php get_footer(); ?>
