(function () {
  'use strict';
  const searchToggle = document.getElementById('jdn-search-toggle');
  const searchPanel = document.getElementById('jdn-search-panel');
  const mobileToggle = document.getElementById('jdn-mobile-toggle');
  const mobileNav = document.getElementById('jdn-mobile-nav');
  const filterButtons = Array.from(document.querySelectorAll('.jdn-filter'));
  const cards = Array.from(document.querySelectorAll('#jdn-latest-grid .jdn-card'));
  const empty = document.getElementById('jdn-filter-empty');

  function closeSearch() {
    if (searchPanel && searchToggle) {
      searchPanel.classList.remove('is-open');
      searchToggle.setAttribute('aria-expanded', 'false');
    }
  }
  if (searchToggle && searchPanel) {
    searchToggle.addEventListener('click', function () {
      const open = searchPanel.classList.toggle('is-open');
      searchToggle.setAttribute('aria-expanded', String(open));
      if (open) {
        const input = searchPanel.querySelector('input[type="search"]');
        if (input) input.focus();
      }
    });
  }
  if (mobileToggle && mobileNav) {
    mobileToggle.addEventListener('click', function () {
      const open = mobileNav.classList.toggle('is-open');
      mobileToggle.setAttribute('aria-expanded', String(open));
      mobileToggle.setAttribute('aria-label', open ? 'मेन्यू बंद करें' : 'मेन्यू खोलें');
    });
    mobileNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        mobileNav.classList.remove('is-open');
        mobileToggle.setAttribute('aria-expanded', 'false');
        mobileToggle.setAttribute('aria-label', 'मेन्यू खोलें');
      });
    });
  }
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closeSearch();
      if (mobileNav && mobileToggle) {
        mobileNav.classList.remove('is-open');
        mobileToggle.setAttribute('aria-expanded', 'false');
        mobileToggle.setAttribute('aria-label', 'मेन्यू खोलें');
      }
    }
  });
  if (filterButtons.length && cards.length) {
    filterButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        const filter = button.getAttribute('data-filter');
        let visible = 0;
        filterButtons.forEach(function (item) {
          item.setAttribute('aria-pressed', String(item === button));
        });
        cards.forEach(function (card) {
          const matches = filter === 'all' || Array.from(card.classList).some(function (className) {
            return className.indexOf('category-') === 0 && className.substring(9) === filter;
          });
          card.hidden = !matches;
          if (matches) visible += 1;
        });
        if (empty) empty.hidden = visible > 0;
      });
    });
  }
})();
