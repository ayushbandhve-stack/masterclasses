<?php
/**
 * WordPress search form.
 *
 * @package JanDristi_News
 */
?>
<form role="search" method="get" class="jdn-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="jdn-search-field"><?php esc_html_e( 'खबर खोजें', 'jandristi-news' ); ?></label>
	<div class="jdn-search-row"><input type="search" id="jdn-search-field" class="jdn-search-input" placeholder="<?php esc_attr_e( 'खबर खोजें…', 'jandristi-news' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" name="s"><button class="jdn-button" type="submit"><?php esc_html_e( 'खोजें', 'jandristi-news' ); ?></button></div>
</form>
